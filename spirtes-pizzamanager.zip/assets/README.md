# Sprite Pack pixel-art

Ogni cartella contiene:
- sheet_1x.png / sheet_4x.png / sheet_8x.png: tutti i frame in una riga orizzontale
- frames/: ogni frame singolo (1x e 8x)
- data.json: dimensioni frame, animazioni (indici frame) e fps

Sfondo trasparente. Per scalare usa nearest-neighbor (niente smoothing).

## Peppo (18×28 px, 11 frame)
- idle: frame 1, 1, 2, 2, 1, 1, 2, 2, 3, 1 @ 6 fps
- cammina: frame 8, 9, 10, 11 @ 8 fps
- salto: frame 4, 5, 5, 5, 6, 1 @ 8 fps
- felice: frame 7, 1, 7, 1 @ 6 fps

## Fizzo (18×32 px, 11 frame)
- idle: frame 1, 1, 2, 2, 1, 1, 2, 2, 3, 1 @ 6 fps
- cammina: frame 8, 9, 10, 11 @ 8 fps
- salto: frame 4, 5, 5, 5, 6, 1 @ 8 fps
- felice: frame 7, 1, 7, 1 @ 6 fps

## Rotolacampo (22×30 px, 20 frame)
- rotola: frame 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 @ 6 fps
- rimbalzo: frame 13, 14, 15, 16, 17, 18, 19, 20 @ 6 fps

## Babbo Natale (52×22 px, 4 frame)
- volo: frame 1, 2, 3, 4 @ 8 fps
