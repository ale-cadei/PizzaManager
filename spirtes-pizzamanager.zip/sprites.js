(function (root) {
const G = (w, h) => Array.from({ length: h }, () => Array(w).fill('.'));
const set = (g, x, y, c) => { if (y >= 0 && y < g.length && x >= 0 && x < g[0].length) g[y][x] = c; };
const stamp = (g, rows, ox, oy) => rows.forEach((r, y) => { for (let x = 0; x < r.length; x++) if (r[x] !== '.') set(g, ox + x, oy + y, r[x]); });
const out = g => g.map(r => r.join(''));

function biped(cfg, o = {}) {
  let rows = cfg.body.map((r, i) => ({ r, i }));
  if (o.squash) rows = rows.filter(x => !cfg.squashRows.includes(x.i));
  if (o.stretch) rows = rows.flatMap(x => cfg.squashRows.includes(x.i) ? [x, x] : [x]);
  const strs = rows.map(x => x.r.split(''));
  const e = strs.findIndex(r => r.includes('E'));
  if (o.blink) { strs[e] = strs[e].map(c => c === 'E' ? cfg.fill : c); strs[e + 1] = strs[e + 1].map(c => c === 'E' ? 'K' : c); }
  if (o.happy) {
    const cols = strs[e].map((c, i) => c === 'E' ? i : -1).filter(i => i >= 0);
    cols.forEach(i => { strs[e][i] = 'K'; strs[e + 1][i] = cfg.fill; });
    cols.forEach(i => { if (!cols.includes(i - 1)) strs[e + 1][i - 1] = 'K'; if (!cols.includes(i + 1)) strs[e + 1][i + 1] = 'K'; });
  }
  const legH = o.tuck ? 2 : 3;
  const top = cfg.H - strs.length - legH - (o.lift || 0);
  const g = G(cfg.W, cfg.H);
  stamp(g, strs.map(r => r.join('')), 1, top);
  const y0 = top + strs.length;
  const legs = o.legs || (o.tuck ? ['up', 'up'] : ['down', 'down']);
  cfg.legX.forEach((x, s) => {
    const d = s ? 1 : -1;
    if (legs[s] === 'down') { set(g, x, y0, 'K'); set(g, x, y0 + 1, 'K'); set(g, x, y0 + 2, 'K'); set(g, x + d, y0 + 2, 'K'); }
    else { set(g, x, y0, 'K'); set(g, x, y0 + 1, 'K'); set(g, x + d, y0 + 1, 'K'); }
  });
  const armY = top + rows.findIndex(x => x.i === cfg.armRow);
  const arms = o.arms || (o.armsUp ? ['up', 'up'] : ['down', 'down']);
  cfg.armX.forEach((x, s) => {
    const d = s ? 1 : -1;
    const pts = arms[s] === 'up' ? [[0, 0], [1, -1], [1, -2], [1, -3]] : arms[s] === 'out' ? [[0, 0], [1, 0], [2, -1]] : [[0, 0], [1, 1], [1, 2]];
    pts.forEach(([dx, dy]) => set(g, x + dx * d, armY + dy, 'K'));
  });
  return out(g);
}

const BIPED_FRAMES = [
  ['idle', {}], ['idle-bob', { lift: 1 }], ['blink', { blink: true }], ['carica', { squash: true }],
  ['salto', { stretch: true, lift: 4, armsUp: true, tuck: true }], ['atterraggio', { squash: true, blink: true }],
  ['felice', { happy: true, armsUp: true, lift: 1 }],
  ['passo-1', { legs: ['up', 'down'], arms: ['out', 'down'], lift: 1 }], ['passo-2', {}],
  ['passo-3', { legs: ['down', 'up'], arms: ['down', 'out'], lift: 1 }], ['passo-4', {}]
];
const BIPED_ANIMS = { idle: { frames: [0, 0, 1, 1, 0, 0, 1, 1, 2, 0], fps: 6 }, cammina: { frames: [7, 8, 9, 10], fps: 8 }, salto: { frames: [3, 4, 4, 4, 5, 0], fps: 8 }, felice: { frames: [6, 0, 6, 0], fps: 6 } };
function bipedSprite(meta, cfg) {
  return Object.assign(meta, { w: cfg.W, h: cfg.H, frames: BIPED_FRAMES.map(([, o]) => biped(cfg, o)), labels: BIPED_FRAMES.map(([n]) => n), anims: BIPED_ANIMS });
}

const peppo = bipedSprite({ id: 'peppo', name: 'Peppo', desc: 'Fetta di pizza', bg: '#6fb7d9',
  palette: { K: ['Contorno', '#3a1f14'], C: ['Crosta', '#d98a3a'], c: ['Crosta ombra', '#a85a24'], Y: ['Formaggio', '#ffd24a'], y: ['Formaggio ombra', '#eda232'], R: ['Salame', '#c8342c'], r: ['Salame luce', '#ef6a50'], E: ['Occhio', '#ffffff'], M: ['Bocca', '#6b1e1e'], T: ['Lingua', '#ff8c9a'] } }, {
  W: 18, H: 28, legX: [7, 10], armX: [2, 15], armRow: 9, squashRows: [5, 8], fill: 'Y',
  body: [
    "..KKKKKKKKKKKK..", ".KCCCCCCCCCCCCK.", "KCCcCCCCCCCcCCCK", "KccccccccccccccK",
    "KYYYYYYRrYYYYYYK", ".KYYYYYRRYYYYYK.", ".KYEEYYYYYYEEYK.", ".KYEKYYYYYYEKYK.",
    "..KYYYYYYYYYYK..", "..KYyMMMMMMyYK..", "...KYyMTTMyYK...", "...KYRRYYYyYK...",
    "....KYRRYYyK....", "....KyYYRrYK....", ".....KYYyYK.....", ".....KyYYyK.....",
    "......KYYK......", ".......KK......."
  ] });

const fizzo = bipedSprite({ id: 'fizzo', name: 'Fizzo', desc: 'Bibita', bg: '#8fd3a8',
  palette: { K: ['Contorno', '#2b1418'], R: ['Rosso', '#d8303a'], r: ['Rosso ombra', '#9e1f2a'], h: ['Rosso luce', '#f2665e'], W: ['Scritte', '#ffffff'], L: ['Coperchio', '#eef0f5'], l: ['Coperchio ombra', '#b9bcc8'], E: ['Occhio', '#ffffff'], M: ['Bocca', '#5a1418'], T: ['Lingua', '#ff8c9a'] } }, {
  W: 18, H: 32, legX: [6, 11], armX: [2, 15], armRow: 13, squashRows: [12, 19], fill: 'R',
  body: [
    ".........KKKK...", ".........KRRK...", ".........KWWK...", ".........KRRK...", ".........KWWK...",
    ".KKKKKKKKKRRKKK.", "KLLLLLLLLLLLLLLK", "KllllllllllllllK", "KKKKKKKKKKKKKKKK",
    ".KhRRRRRRRRRRrK.", ".KhREERRRREERrK.", ".KhREKRRRREKRrK.", ".KhRRRRRRRRRRrK.",
    "..KhRMMMMMMRrK..", "..KhRRMTTMRRrK..", "..KhRRRRRRRRrK..",
    "..KWWWWWWWWWWK..", "..KWRWRWWRWRWK..", "..KWWWWWWWWWWK..",
    "..KhRRRRRRRRrK..", "...KhRRRRRRrK...", "...KhRRRRRRrK...", "...KKKKKKKKKK..."
  ] });

// strands: [cx, cy, rx, ry, tilt°, from°, to°, color]
const STRANDS = [
  [0.5, 0, 9, 7, 10, 0, 285, 'K'], [-0.5, 0.5, 6.8, 9, -30, 60, 370, 'K'],
  [0, -0.5, 8.4, 4.2, 135, 70, 320, 'B'], [-1, 0.5, 4, 7.8, 95, 0, 220, 'B'],
  [1.5, -1, 5.4, 2.6, 55, 0, 290, 'b'], [-1.5, 2, 3.6, 2, -15, 140, 420, 'b']
];
// twigs: [angle°, r0, r1, color, forkAngle°]
const TWIGS = [[18, 6.5, 10, 'K', 40], [112, 7, 9.6, 'B', 0], [205, 6, 10, 'K', -35], [292, 6.5, 9, 'B', 30], [250, 7.5, 9.2, 'b', 0], [60, 7, 8.8, 'b', 0]];
function twFrame(deg, lift) {
  const W = 22, H = 30, g = G(W, H), cx = 10.5, cy = H - 11 - lift, th = deg * Math.PI / 180;
  const plot = (x, y, c) => { const X = x * Math.cos(th) - y * Math.sin(th), Y = x * Math.sin(th) + y * Math.cos(th); set(g, Math.round(cx + X), Math.round(cy + Y), c); };
  ['K', 'B', 'b'].forEach(col => {
    STRANDS.filter(s => s[7] === col).forEach(([ox, oy, rx, ry, tl, a0, a1]) => {
      const t0 = tl * Math.PI / 180;
      for (let a = a0; a <= a1; a += 2) { const t = a * Math.PI / 180, x = rx * Math.cos(t), y = ry * Math.sin(t); plot(ox + x * Math.cos(t0) - y * Math.sin(t0), oy + x * Math.sin(t0) + y * Math.cos(t0), col); }
    });
    TWIGS.filter(t => t[3] === col).forEach(([a, r0, r1, , fk]) => {
      const t = a * Math.PI / 180;
      for (let r = r0; r <= r1; r += 0.25) plot(r * Math.cos(t), r * Math.sin(t), col);
      if (fk) { const bx = r1 * 0.85 * Math.cos(t), by = r1 * 0.85 * Math.sin(t), f = (a + fk) * Math.PI / 180; for (let r = 0; r <= 2; r += 0.25) plot(bx + r * Math.cos(f), by + r * Math.sin(f), col); }
    });
  });
  return out(g);
}
const ROLL = Array.from({ length: 12 }, (_, i) => i * 30);
const BOUNCE = [0, 3, 5, 6, 5, 3, 0, 0];
const tumble = { id: 'rotolacampo', name: 'Rotolacampo', desc: 'Palla del west', bg: '#e8c68e', w: 22, h: 30,
  palette: { K: ['Rami scuri', '#5a3a1e'], B: ['Rami', '#8e6232'], b: ['Rami chiari', '#c49a5a'] },
  frames: [...ROLL.map(d => twFrame(d, 0)), ...BOUNCE.map((l, i) => twFrame(i * 45, l))],
  labels: [...ROLL.map((_, i) => `rot-${i + 1}`), ...BOUNCE.map((_, i) => `rimb-${i + 1}`)],
  anims: { rotola: { frames: ROLL.map((_, i) => i), fps: 6 }, rimbalzo: { frames: BOUNCE.map((_, i) => 12 + i), fps: 6 } } };

const SANTA = [
  "......KKKK....", ".KKK.KRRRRK...", "KWWKKRRRRRRK..", "KWWKRRRRRRRRK.", ".KKKWWWWWWWWWK",
  "....KSSSSKSSSK", "....KWSSSSSnSK", "...KWWWWSSWWWK", "..KRWWWWWWWWWK", ".KRRKWWWWWKRRK",
  ".KRRRRRKKKRRRK", ".KRRRRRRRRRRRK"
];
const SLEIGH = [
  "KKK.................", "KRRK..............KK", "KRRKKKKKKKKKKKKKKKRK", "KRGGGGGGGGGGGGGGGRK.",
  "KRRRRRRRRRRRRRRRRK..", ".KrrrrrrrrrrrrrrK...", "..KKKKKKKKKKKKKK....", "...G........G.....G.",
  ".gGGGGGGGGGGGGGGGGg.", "..KKKKKKKKKKKKKKKK.."
];
const DEER = [
  "..........A.A.", "..........AAA.", ".........KKKK.", "........KBBKBK", "........KBBBBN",
  ".........KbbK.", "..KKKKKKKBBK..", ".KBBBBBBBBBK..", "KbKBBBBBBBBK..", ".KbbbbbbbbbK.."
];
const LEGS = { A: [[2, 10], [1, 11], [0, 12], [10, 10], [11, 11], [12, 12]], B: [[3, 10], [4, 11], [9, 10], [8, 11]], C: [[2, 10], [2, 11], [2, 12], [10, 10], [10, 11], [10, 12]] };
function deer(g, ox, oy, pose, nose) {
  stamp(g, DEER.map(r => r.replace('N', nose)), ox, oy);
  set(g, ox + 9, oy + 7, 'G');
  LEGS[pose].forEach(([x, y]) => set(g, ox + x, oy + y, 'K'));
}
function santaFrame(f) {
  const g = G(52, 22), X = 4, bob = [0, -1, 0, 1][f];
  [[[1, 8], [3, 13]], [[0, 11], [2, 6]], [[1, 14], [3, 9]], [[0, 7], [2, 12]]][f].forEach(([x, y]) => set(g, x, y + bob, 'G'));
  for (let x = X + 15; x < X + 44; x++) set(g, x, 12 + bob, 'g');
  stamp(g, SANTA, X + 3, 2 + bob);
  stamp(g, SLEIGH, X, 10 + bob);
  deer(g, X + 20, 6 + [1, 0, -1, 0][f], 'ACBC'[f], 'K');
  deer(g, X + 34, 6 + [-1, 0, 1, 0][f], 'BCAC'[f], f % 2 ? 'N' : 'M');
  return out(g);
}
const santa = { id: 'babbo-natale', name: 'Babbo Natale', desc: 'Slitta e renne', bg: '#1f2d52', w: 52, h: 22,
  palette: { K: ['Contorno', '#1f1420'], R: ['Rosso', '#d32f3a'], r: ['Rosso ombra', '#8e1c2a'], W: ['Bianco', '#f4f1ea'], S: ['Pelle', '#f2b58a'], n: ['Naso', '#e0806a'], B: ['Renna', '#8a5530'], b: ['Renna chiaro', '#c08850'], A: ['Corna', '#e0c080'], G: ['Oro', '#f2c14e'], g: ['Oro scuro', '#b8862a'], N: ['Naso renna', '#ff3b3b'], M: ['Naso renna spento', '#9a2030'] },
  frames: [0, 1, 2, 3].map(santaFrame), labels: ['volo-1', 'volo-2', 'volo-3', 'volo-4'],
  anims: { volo: { frames: [0, 1, 2, 3], fps: 8 } } };

function draw(ctx, sp, f, ox, oy, s) {
  sp.frames[f].forEach((row, y) => { for (let x = 0; x < row.length; x++) { const c = row[x]; if (c === '.' || !sp.palette[c]) continue; ctx.fillStyle = sp.palette[c][1]; ctx.fillRect(ox + x * s, oy + y * s, s, s); } });
}
root.SPRITES = [peppo, fizzo, tumble, santa];
root.drawSprite = draw;
})(typeof window !== 'undefined' ? window : this);
