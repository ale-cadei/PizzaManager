(function (root) {
const G = (w, h) => Array.from({ length: h }, () => Array(w).fill('.'));
const set = (g, x, y, c) => { if (y >= 0 && y < g.length && x >= 0 && x < g[0].length) g[y][x] = c; };
const stamp = (g, rows, ox, oy) => rows.forEach((r, y) => { for (let x = 0; x < r.length; x++) if (r[x] !== '.') set(g, ox + x, oy + y, r[x]); });
const out = g => g.map(r => r.join(''));

function biped(cfg, o = {}) {
  let rows = cfg.body.map((r, i) => ({ r, i }));
  if (o.squash) rows = rows.filter(x => !cfg.squashRows.includes(x.i));
  if (o.stretch) rows = rows.flatMap(x => cfg.squashRows.includes(x.i) ? [x, x] : [x]);
  const strs = rows.map(x => x.r.split(''));
  const e = strs.findIndex(r => r.includes('E'));
  if (o.blink) { strs[e] = strs[e].map(c => c === 'E' ? cfg.fill : c); strs[e + 1] = strs[e + 1].map(c => c === 'E' ? 'K' : c); }
  if (o.happy) {
    const cols = strs[e + 1].map((c, i) => c === 'E' ? i : -1).filter(i => i >= 0);
    strs[e] = strs[e].map(c => c === 'E' ? cfg.fill : c);
    cols.forEach(i => { strs[e][i] = 'K'; strs[e + 1][i] = cfg.fill; });
    cols.forEach(i => { if (!cols.includes(i - 1)) strs[e + 1][i - 1] = 'K'; if (!cols.includes(i + 1)) strs[e + 1][i + 1] = 'K'; });
  }
  const legH = o.tuck ? 2 : 3;
  const top = cfg.H - strs.length - legH - (o.lift || 0);
  const g = G(cfg.W, cfg.H);
  stamp(g, strs.map(r => r.join('')), 1, top);
  const y0 = top + strs.length;
  const legs = o.legs || (o.tuck ? ['up', 'up'] : ['down', 'down']);
  cfg.legX.forEach((x, s) => {
    const d = s ? 1 : -1;
    if (legs[s] === 'down') { set(g, x, y0, 'K'); set(g, x, y0 + 1, 'K'); set(g, x, y0 + 2, 'K'); set(g, x + d, y0 + 2, 'K'); }
    else { set(g, x, y0, 'K'); set(g, x, y0 + 1, 'K'); set(g, x + d, y0 + 1, 'K'); }
  });
  const armY = top + rows.findIndex(x => x.i === cfg.armRow);
  const arms = o.arms || (o.armsUp ? ['up', 'up'] : ['down', 'down']);
  cfg.armX.forEach((x, s) => {
    const d = s ? 1 : -1;
    const pts = arms[s] === 'up' ? [[0, 0], [1, -1], [1, -2], [1, -3]] : arms[s] === 'out' ? [[0, 0], [1, 0], [2, -1]] : [[0, 0], [1, 1], [1, 2]];
    pts.forEach(([dx, dy]) => set(g, x + dx * d, armY + dy, 'K'));
  });
  return out(g);
}
const BIPED_FRAMES = [
  ['idle', {}], ['idle-bob', { lift: 1 }], ['blink', { blink: true }], ['carica', { squash: true }],
  ['salto', { stretch: true, lift: 4, armsUp: true, tuck: true }], ['atterraggio', { squash: true, blink: true }],
  ['felice', { happy: true, armsUp: true, lift: 1 }],
  ['passo-1', { legs: ['up', 'down'], arms: ['out', 'down'], lift: 1 }], ['passo-2', {}],
  ['passo-3', { legs: ['down', 'up'], arms: ['down', 'out'], lift: 1 }], ['passo-4', {}]
];
const BIPED_ANIMS = { idle: { frames: [0, 0, 1, 1, 0, 0, 1, 1, 2, 0], fps: 6 }, cammina: { frames: [7, 8, 9, 10], fps: 8 }, salto: { frames: [3, 4, 4, 4, 5, 0], fps: 8 }, felice: { frames: [6, 0, 6, 0], fps: 6 } };

// ZUCCA
const zucco = { id: 'zucco', name: 'Zucco', desc: 'Zucca di Halloween', bg: '#3b2a4f',
  palette: { K: ['Contorno', '#3a1a0a'], O: ['Arancio', '#f07a1c'], o: ['Arancio ombra', '#b8500e'], h: ['Arancio luce', '#ffa24a'], G: ['Picciolo', '#4a8a2c'], g: ['Picciolo ombra', '#2e5a1c'], E: ['Occhi luce', '#ffe45c'], F: ['Bocca luce', '#ffb020'] } };
const ZCFG = { W: 22, H: 24, legX: [8, 13], armX: [2, 19], armRow: 7, squashRows: [4, 11], fill: 'O',
  body: [
    ".......KK.......", "......KGgK......", "..KKKKKGgKKKKK..", ".KOOhOOKOOOhOOK.",
    "KOhOOoOOOOoOOhOK", "KOhOEoOOOOoEOhOK", "KOhEEEOOOOEEEhOK", "KOhOOoOOOOoOOhOK",
    "KOhFOOoOOoOOFhOK", "KOhFFFFFFFFFFhOK", "KOhOFFOFFOFFOhOK", ".KOhOoOOOOoOOhK.",
    "..KKOOOoOOoOKK..", "....KKKKKKKK...."
  ].map(r => '..' + r + '..') };
Object.assign(zucco, { w: ZCFG.W, h: ZCFG.H, frames: BIPED_FRAMES.map(([, o]) => biped(ZCFG, o)), labels: BIPED_FRAMES.map(([n]) => n), anims: BIPED_ANIMS });

// FANTASMINO
const GH_W = [6, 10, 12, 14, 14, 16, 16, 16, 16, 16, 16, 16, 16, 16, 14, 14, 14, 12, 12, 10, 10, 8, 8];
const GH_FACE = { 5: "KWWKKWWWWWWKKWwK", 6: "KWWWWKWWWWKWWWwK", 7: "KWWWDRWWWWRDWWwK", 8: "KWWWDDWWWWDDWWwK", 10: "KWWWKWWWWWWKWWwK", 11: "KWWWWKTDDTKWWWwK", 12: "KWWWWWKKKKWWWWwK" };
const GH = GH_W.map((w, i) => {
  if (GH_FACE[i]) return GH_FACE[i];
  const p = (16 - w) / 2, inner = w - 2;
  const fill = i < 2 ? 'W'.repeat(inner) : 'W'.repeat(inner - 1) + 'w';
  return '.'.repeat(p) + 'K' + fill + 'K' + '.'.repeat(p);
});
const GH_TAIL = [
  ["......KWWwK.....", ".......KWwK.....", "........KWK.....", ".........K......"],
  [".....KWWWwK.....", "......KWWK......", "......KWK.......", ".......K........"],
  ["....KWWWwK......", "....KWWwK.......", "....KWK.........", "....K..........."]
];
const CH_TAIL = [
  ["...KWWWWwK......", "..KWWWKK........", ".KWKK...........", "KK.............."],
  ["....KWWWwK......", "...KWWKK........", "..KWKK..........", "..KK............"]
];
const GH_BOO = ["KWWWWKKKKKKWWWwK", "KWWWKTDDDDTKWWwK", "KWWWKDDDDDDKWWwK", "KWWWWKKKKKKWWWwK"];
const mir = rows => rows.map(r => r.split('').reverse().join(''));
const GW = 24, GHH = 32;
function ghost(o) {
  const g = G(GW, GHH); let rows = GH.slice();
  if (o.squint) { rows[7] = rows[7].replace(/[DR]/g, 'K'); rows[8] = rows[8].replace(/D/g, 'W'); }
  if (o.boo) rows.splice(10, 4, ...GH_BOO);
  rows = rows.concat(GH_TAIL[o.tail]);
  const top = GHH - rows.length - o.lift;
  stamp(g, rows, 4, top);
  return out(g);
}
function chase(o) {
  const g = G(GW, GHH); const body = GH.slice();
  body[7] = "KWWWDDWWWWDDWWwK"; body[8] = "KWWWDRWWWWDRWWwK";
  const rows = body.concat(CH_TAIL[o.tail]);
  const top = GHH - rows.length - o.lift;
  stamp(g, rows, 4, top);
  return out(g);
}
const CH = [{ lift: 2, tail: 0, arm: 0 }, { lift: 3, tail: 1, arm: -1 }, { lift: 2, tail: 0, arm: 0 }, { lift: 1, tail: 1, arm: 1 }];
const GF = [['fluttua-1', ghost({ lift: 1, tail: 0 })], ['fluttua-2', ghost({ lift: 2, tail: 1 })], ['fluttua-3', ghost({ lift: 3, tail: 2 })], ['fluttua-4', ghost({ lift: 2, tail: 1 })],
  ['sguardo', ghost({ lift: 1, tail: 0, squint: true })], ['buu-1', ghost({ lift: 2, tail: 1, boo: true })], ['buu-2', ghost({ lift: 3, tail: 2, boo: true })],
  ...CH.map((o, i) => [`insegui-dx-${i + 1}`, chase(o)]), ...CH.map((o, i) => [`insegui-sx-${i + 1}`, mir(chase(o))])];
const fantasmino = { id: 'fantasmino', name: 'Fantasmino', desc: 'Fantasma dispettoso', bg: '#3b2a4f', w: GW, h: GHH,
  palette: { K: ['Contorno', '#1e1a2a'], W: ['Lenzuolo', '#eeeaf6'], w: ['Lenzuolo ombra', '#b9b2cc'], D: ['Occhi', '#2a1030'], R: ['Luce occhi', '#ff5060'], T: ['Dentini', '#ffffff'] },
  frames: GF.map(f => f[1]), labels: GF.map(f => f[0]),
  anims: { fluttua: { frames: [0, 1, 2, 3, 0, 1, 2, 3, 4, 4], fps: 5 }, 'insegui-dx': { frames: [7, 8, 9, 10], fps: 7 }, 'insegui-sx': { frames: [11, 12, 13, 14], fps: 7 }, 'avanti-indietro': { frames: [7, 8, 9, 10, 7, 8, 9, 10, 4, 11, 12, 13, 14, 11, 12, 13, 14, 4], fps: 7, walk: [1, -1] }, buu: { frames: [0, 5, 6, 6, 6, 5, 0], fps: 6 } } };

// LA MORTE
const RM = ".KHHHHh", RS = "HHHK.";
const ROBE = [
  "........KKKK........", "......KKHHHHKK......", ".....KHHHHHHHHK.....", "....KHHHhHHHHHHK....",
  "....KHhKKKKKKKKHK...",
  "...KHhKDSSSSSSDKHK..", "...KHhKSSSSSSSSKHK..", "...KHhKSDDSSDDSKHK..", "...KHhKSDESSEDSKHK..",
  "...KHhKsSSDDSSsKHK..", "...KHhKDsSSSSsDKHK..", "...KHhKDSKSKSKDKHK..", "..KHHhKDDssssDDKHHK.",
  "..KHHHhKKKKKKKKHHHK.",
  RM + "KsSSSSsK" + RS, RM + "KDDSSDDK" + RS, RM + "KsSSSSsK" + RS, RM + "KDDSSDDK" + RS, RM + "HKsSSsKH" + RS, RM + "HHKSSKHH" + RS,
  "KHHHhHHHHHHHHHHHhHHK", "KHHHhHHHHHHHHHHHhHHK", "KHHhHHHHHHHHHHHHhhHK", "KHHhHHHHHHHHHHHHhhHK"
];
const HEM = [["KHhKHHHKHHHKHHKHHhHK", ".KK.KKK.KKK.KK.KKKK."], ["KHhHKHHHKHHHKHHKHhHK", ".KKK.KKK.KKK.KK.KKK."]];
const SCY = [
  "....KKKKKKKKKKK.", "..KKMMMMMMMMMmBK", ".KMMmmmmKKKKKKBK", "KMmKKKK.......BK", "KmK...........BK", "K.............BK",
  ...Array(26).fill("..............BK")
];
function reaper(o) {
  const W = 48, H = 34, g = G(W, H), rx = 14, ry = H - 26 - 2 - o.lift;
  let robe = ROBE.concat(HEM[o.hem]);
  if (o.dim) robe = robe.map(r => r.replace(/E/g, 'e'));
  stamp(g, robe, rx, ry);
  set(g, rx, ry + 17, 'S'); set(g, rx - 1, ry + 18, 'S'); set(g, rx, ry + 18, 's'); set(g, rx - 1, ry + 19, 's');
  const px = rx + 20, py = ry + 15, th = (o.angle || 0) * Math.PI / 180, c = Math.cos(th), s = Math.sin(th);
  for (let ty = 0; ty < H; ty++) for (let tx = 0; tx < W; tx++) {
    const dx = tx - px, dy = ty - py, u = Math.round(14 + dx * c + dy * s), v = Math.round(16 - dx * s + dy * c);
    const ch = SCY[v] && SCY[v][u];
    if (ch && ch !== '.') set(g, tx, ty, ch);
  }
  set(g, px - 1, py, 'S'); set(g, px + 1, py, 'S'); set(g, px - 1, py + 1, 's'); set(g, px + 1, py + 1, 's');
  return out(g);
}
const SWING = [0, 20, 40, -25, -60, -75, -45, -15];
const RF = [['fluttua-1', { lift: 0, hem: 0 }], ['fluttua-2', { lift: 1, hem: 1 }], ['fluttua-3', { lift: 2, hem: 0 }], ['fluttua-4', { lift: 1, hem: 1 }],
  ['occhi-spenti', { lift: 0, hem: 0, dim: true }], ...SWING.map((a, i) => [`falciata-${i + 1}`, { lift: 1, hem: i % 2, angle: a }])];
const morte = { id: 'la-morte', name: 'La Morte', desc: 'Con la falce', bg: '#3b2a4f', w: 48, h: 34,
  palette: { K: ['Contorno', '#050307'], H: ['Veste', '#141018'], h: ['Veste pieghe', '#2a2430'], D: ['Buio', '#000000'], S: ['Osso', '#efe8d6'], s: ['Osso ombra', '#b5ab96'], E: ['Occhi', '#8cff9e'], e: ['Occhi spenti', '#2f6b3c'], B: ['Manico', '#7a5230'], M: ['Lama', '#d3dae4'], m: ['Lama ombra', '#8a94a3'] },
  frames: RF.map(([, o]) => reaper(o)), labels: RF.map(([n]) => n),
  anims: { fluttua: { frames: [0, 1, 2, 3], fps: 4 }, occhi: { frames: [0, 0, 0, 4, 0, 4, 0, 0], fps: 6 }, falciata: { frames: [0, 5, 6, 7, 8, 9, 10, 11, 12, 0], fps: 10 } } };

function draw(ctx, sp, f, ox, oy, s) {
  sp.frames[f].forEach((row, y) => { for (let x = 0; x < row.length; x++) { const c = row[x]; if (c === '.' || !sp.palette[c]) continue; ctx.fillStyle = sp.palette[c][1]; ctx.fillRect(ox + x * s, oy + y * s, s, s); } });
}
root.SPRITES = [fantasmino, morte, zucco];
root.drawSprite = draw;
})(typeof window !== 'undefined' ? window : this);
