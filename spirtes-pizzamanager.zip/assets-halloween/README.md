# Halloween Pack pixel-art

Ogni cartella contiene:
- sheet_1x.png / sheet_4x.png / sheet_8x.png: tutti i frame in una riga orizzontale
- frames/: ogni frame singolo (1x e 8x)
- data.json: dimensioni frame, animazioni (indici frame) e fps

Sfondo trasparente. Per scalare usa nearest-neighbor (niente smoothing).

Fantasmino (pet): usa insegui-dx mentre sposti lo sprite verso destra e insegui-sx verso sinistra; "avanti-indietro" è la sequenza completa andata/ritorno con una pausa "sguardo" a ogni cambio di direzione.

## Fantasmino (24×32 px, 15 frame)
- fluttua: frame 1, 2, 3, 4, 1, 2, 3, 4, 5, 5 @ 5 fps
- insegui-dx: frame 8, 9, 10, 11 @ 7 fps
- insegui-sx: frame 12, 13, 14, 15 @ 7 fps
- avanti-indietro: frame 8, 9, 10, 11, 8, 9, 10, 11, 5, 12, 13, 14, 15, 12, 13, 14, 15, 5 @ 7 fps
- buu: frame 1, 6, 7, 7, 7, 6, 1 @ 6 fps

## La Morte (48×34 px, 13 frame)
- fluttua: frame 1, 2, 3, 4 @ 4 fps
- occhi: frame 1, 1, 1, 5, 1, 5, 1, 1 @ 6 fps
- falciata: frame 1, 6, 7, 8, 9, 10, 11, 12, 13, 1 @ 10 fps

## Zucco (22×24 px, 11 frame)
- idle: frame 1, 1, 2, 2, 1, 1, 2, 2, 3, 1 @ 6 fps
- cammina: frame 8, 9, 10, 11 @ 8 fps
- salto: frame 4, 5, 5, 5, 6, 1 @ 8 fps
- felice: frame 7, 1, 7, 1 @ 6 fps
